
ENSF Final Project (2) - v1 Omitted images
==============================

This dataset was exported via roboflow.ai on April 8, 2022 at 6:06 AM GMT

It includes 340 images.
Box are annotated in YOLO v3 Darknet format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* 50% probability of vertical flip
* Random rotation of between -10 and +10 degrees


